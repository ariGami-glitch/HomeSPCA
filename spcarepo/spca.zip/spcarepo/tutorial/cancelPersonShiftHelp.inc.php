
<p>
	<strong>How to Cancel Your Shift</strong>
<p>
	<B>Step 1:</B>
</p>
<p>
	If you need to cancel an upcoming shift, you may either call the Ronald McDonald House
	to remove your name from the calendar or proceed to <B>Step 2</B>.
</p>
<p>
	<B>Step 2:</B>
<p>
	To remove your own name from an upcoming shift on the calendar, you can follow <a
		href="help.php?helpPage=rmhp-homebase/addPersonToShift.php">these instructions</a>.
</p>
